sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend("ics.prd.prod.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
