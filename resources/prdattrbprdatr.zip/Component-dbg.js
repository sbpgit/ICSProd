sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend("prdattrb.prdatr.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
